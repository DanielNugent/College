public class DirectedEdge {
    public int v; //starting vertex
    public int w; //ending vertex
    public double weight;
    //Directed Edge class constructor
    public DirectedEdge(int v, int w, double weight) {
    	this.v = v;
    	this.w = w;
    	this.weight = weight;
   }
	
}
